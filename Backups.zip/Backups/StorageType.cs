﻿namespace Backups
{
    public enum StorageType
    {
        Local = 0,
        Virtual,
    }
}